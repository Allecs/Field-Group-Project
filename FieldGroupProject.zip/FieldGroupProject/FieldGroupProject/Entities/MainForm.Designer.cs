﻿namespace FieldGroupProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IdNumberTb = new System.Windows.Forms.TextBox();
            this.IdNumberLabel = new System.Windows.Forms.Label();
            this.FNameLabel = new System.Windows.Forms.Label();
            this.FNameTb = new System.Windows.Forms.TextBox();
            this.LNameTb = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.MajorLabel = new System.Windows.Forms.Label();
            this.MajorTb = new System.Windows.Forms.TextBox();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.ReligionLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // IdNumberTb
            // 
            this.IdNumberTb.Location = new System.Drawing.Point(140, 96);
            this.IdNumberTb.Name = "IdNumberTb";
            this.IdNumberTb.Size = new System.Drawing.Size(100, 20);
            this.IdNumberTb.TabIndex = 0;
            // 
            // IdNumberLabel
            // 
            this.IdNumberLabel.AutoSize = true;
            this.IdNumberLabel.Location = new System.Drawing.Point(55, 96);
            this.IdNumberLabel.Name = "IdNumberLabel";
            this.IdNumberLabel.Size = new System.Drawing.Size(58, 13);
            this.IdNumberLabel.TabIndex = 1;
            this.IdNumberLabel.Text = "ID Number";
            // 
            // FNameLabel
            // 
            this.FNameLabel.AutoSize = true;
            this.FNameLabel.Location = new System.Drawing.Point(56, 139);
            this.FNameLabel.Name = "FNameLabel";
            this.FNameLabel.Size = new System.Drawing.Size(57, 13);
            this.FNameLabel.TabIndex = 2;
            this.FNameLabel.Text = "First Name";
            // 
            // FNameTb
            // 
            this.FNameTb.Location = new System.Drawing.Point(140, 136);
            this.FNameTb.Name = "FNameTb";
            this.FNameTb.Size = new System.Drawing.Size(100, 20);
            this.FNameTb.TabIndex = 3;
            // 
            // LNameTb
            // 
            this.LNameTb.Location = new System.Drawing.Point(140, 179);
            this.LNameTb.Name = "LNameTb";
            this.LNameTb.Size = new System.Drawing.Size(100, 20);
            this.LNameTb.TabIndex = 4;
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(56, 182);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.LastNameLabel.TabIndex = 5;
            this.LastNameLabel.Text = "Last Name";
            // 
            // MajorLabel
            // 
            this.MajorLabel.AutoSize = true;
            this.MajorLabel.Location = new System.Drawing.Point(56, 227);
            this.MajorLabel.Name = "MajorLabel";
            this.MajorLabel.Size = new System.Drawing.Size(33, 13);
            this.MajorLabel.TabIndex = 6;
            this.MajorLabel.Text = "Major";
            // 
            // MajorTb
            // 
            this.MajorTb.Location = new System.Drawing.Point(140, 220);
            this.MajorTb.Name = "MajorTb";
            this.MajorTb.Size = new System.Drawing.Size(100, 20);
            this.MajorTb.TabIndex = 7;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(140, 339);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(75, 23);
            this.SubmitButton.TabIndex = 8;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            // 
            // ReligionLabel
            // 
            this.ReligionLabel.AutoSize = true;
            this.ReligionLabel.Location = new System.Drawing.Point(55, 262);
            this.ReligionLabel.Name = "ReligionLabel";
            this.ReligionLabel.Size = new System.Drawing.Size(45, 13);
            this.ReligionLabel.TabIndex = 9;
            this.ReligionLabel.Text = "Religion";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(140, 262);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 10;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ReligionLabel);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.MajorTb);
            this.Controls.Add(this.MajorLabel);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.LNameTb);
            this.Controls.Add(this.FNameTb);
            this.Controls.Add(this.FNameLabel);
            this.Controls.Add(this.IdNumberLabel);
            this.Controls.Add(this.IdNumberTb);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IdNumberTb;
        private System.Windows.Forms.Label IdNumberLabel;
        private System.Windows.Forms.Label FNameLabel;
        private System.Windows.Forms.TextBox FNameTb;
        private System.Windows.Forms.TextBox LNameTb;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Label MajorLabel;
        private System.Windows.Forms.TextBox MajorTb;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Label ReligionLabel;
        private System.Windows.Forms.TextBox textBox1;
    }
}

