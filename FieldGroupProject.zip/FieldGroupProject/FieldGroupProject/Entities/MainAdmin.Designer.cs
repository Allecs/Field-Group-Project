﻿namespace FieldGroupProject
{
    partial class MainAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ViewRoomButton = new System.Windows.Forms.Button();
            this.ResidentViewButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchBarTb = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SecondFloorButton = new System.Windows.Forms.Button();
            this.ThirdFloorButton = new System.Windows.Forms.Button();
            this.FourthFloorButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ViewRoomButton
            // 
            this.ViewRoomButton.Location = new System.Drawing.Point(91, 85);
            this.ViewRoomButton.Name = "ViewRoomButton";
            this.ViewRoomButton.Size = new System.Drawing.Size(127, 28);
            this.ViewRoomButton.TabIndex = 0;
            this.ViewRoomButton.Text = "First Floor Rooms";
            this.ViewRoomButton.UseVisualStyleBackColor = true;
            // 
            // ResidentViewButton
            // 
            this.ResidentViewButton.Location = new System.Drawing.Point(169, 280);
            this.ResidentViewButton.Name = "ResidentViewButton";
            this.ResidentViewButton.Size = new System.Drawing.Size(127, 31);
            this.ResidentViewButton.TabIndex = 1;
            this.ResidentViewButton.Text = "View All Residents";
            this.ResidentViewButton.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 280);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "View All Empty Rooms";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(345, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter Critera";
            // 
            // SearchBarTb
            // 
            this.SearchBarTb.Location = new System.Drawing.Point(465, 93);
            this.SearchBarTb.Name = "SearchBarTb";
            this.SearchBarTb.Size = new System.Drawing.Size(147, 20);
            this.SearchBarTb.TabIndex = 4;
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(618, 89);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(55, 28);
            this.SearchButton.TabIndex = 5;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(127, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "View:";
            // 
            // SecondFloorButton
            // 
            this.SecondFloorButton.Location = new System.Drawing.Point(91, 130);
            this.SecondFloorButton.Name = "SecondFloorButton";
            this.SecondFloorButton.Size = new System.Drawing.Size(127, 28);
            this.SecondFloorButton.TabIndex = 7;
            this.SecondFloorButton.Text = "Second Floor Rooms";
            this.SecondFloorButton.UseVisualStyleBackColor = true;
            // 
            // ThirdFloorButton
            // 
            this.ThirdFloorButton.Location = new System.Drawing.Point(91, 173);
            this.ThirdFloorButton.Name = "ThirdFloorButton";
            this.ThirdFloorButton.Size = new System.Drawing.Size(127, 29);
            this.ThirdFloorButton.TabIndex = 8;
            this.ThirdFloorButton.Text = "Third Floor Rooms";
            this.ThirdFloorButton.UseVisualStyleBackColor = true;
            // 
            // FourthFloorButton
            // 
            this.FourthFloorButton.Location = new System.Drawing.Point(91, 221);
            this.FourthFloorButton.Name = "FourthFloorButton";
            this.FourthFloorButton.Size = new System.Drawing.Size(127, 29);
            this.FourthFloorButton.TabIndex = 9;
            this.FourthFloorButton.Text = "Forth Floor Rooms";
            this.FourthFloorButton.UseVisualStyleBackColor = true;
            // 
            // MainAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FourthFloorButton);
            this.Controls.Add(this.ThirdFloorButton);
            this.Controls.Add(this.SecondFloorButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.SearchBarTb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ResidentViewButton);
            this.Controls.Add(this.ViewRoomButton);
            this.Name = "MainAdmin";
            this.Text = "MainAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ViewRoomButton;
        private System.Windows.Forms.Button ResidentViewButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SearchBarTb;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button SecondFloorButton;
        private System.Windows.Forms.Button ThirdFloorButton;
        private System.Windows.Forms.Button FourthFloorButton;
    }
}